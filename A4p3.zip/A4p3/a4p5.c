/*
JTSK-320111
a4.p5.c
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/

#include <stdio.h>
int main(){

float num1[10];// declaring a variable

for (int i =0; i<10; i++){
    if (num1[i]==99.0){

        break;
    }

    scanf("%f",&num1[i]);

}

sum(num1);
mean(num1);

return 0;

}
/* brief sum is afunction that sums up the elements of the matrix
@param summ is a float variable storesthe value of the summition instantly
*/
int sum (float matrix[10]){
float summ =0;

for (int i=0; i<10; i++){
      summ+=matrix[i];

    }

   printf("the sum=%f\n",summ);

return summ;
}
/*brief: mean is a function that clculates the average value of the matrix element*/
int mean (float matrix[10]){
    float sum=0;
    int i;
    float mean=0;
for (i=0; i<10; i++){

      sum+=matrix[i];


    }


   mean= sum/i;
    printf("the average=%f\n",mean);

    return mean;
}









