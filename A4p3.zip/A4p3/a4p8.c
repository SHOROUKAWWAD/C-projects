
/*
JTSK-320111
a4p8.c
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (){
char one[100];
fgets(one,sizeof(one),stdin);
char two[100];
fgets(two,sizeof(two),stdin);
printf("length1=%d\n",strlen(one)-1);
printf("length2=%d\n",strlen(two)-1);
printf("concatenation=");
for (int i=0; i<strlen(one);i++){

    if (one[i]!='\n'){

        printf("%c",one[i]);
    }
    else{
        printf("%s",two);
    }
}

char *copy;
copy =&two;
printf("copy=%s",copy);
for (int i=0; i>=0; i++){
if (one[i]>two[i]){


    printf("one is larger than two\n");
    break;

}else if (one[i]<two[i]){
printf("one is smaller than two\n");
break;
}else{
printf("one is equal to two\n");
break;
}

}
char C;
scanf("%c",&C);
int count=0;

  for (int i=0; i<strlen(two);i++){

  if (two[i]==C){
        printf("position=%d\n",i);

    }
    else {
         count++;
        continue;
    }

}
if (count==strlen(two)){
    printf("The character is not in the string\n");
}


return 0;

        }























