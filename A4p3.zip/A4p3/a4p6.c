
/*
JTSK-320111
a4p6.c
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <stdio.h>
//brief: this function sum is to sum up the third and the sixth element of the array
//param sum is an integer variable stores the sum
//param v[] is a matrix
 double sum25( int n,double v[n]){
double sum;
sum =0;
sum = v[2]+v[5];

return sum;
}

int main (){
    int n;
scanf("%d",&n);
if (n<=5||n>20){
    printf("One or both positions are invalid\n");
    return -1;
}
else {
double v[n];
for (int i=0; i<n; i++){


scanf("%lf",&v[i]);

}

sum25(n,v);

printf("sum=%lf\n",sum25(n,v));


return 0;
}
}
