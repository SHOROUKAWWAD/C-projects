/*
JTSK-320111
a4p3.c
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <stdio.h>
int main (){

int num1 ;//declaring number
int num2 ;// declaring variable
char thing;

scanf ("%d",&num1);
scanf ("%d",&num2);// to take value from the user
getchar ();
scanf ("%c",&thing);

for (int j=0;j<num1;j++){ //for loop

   for (int i=0;i< num2; i++) {

    printf("%c",thing);

   }

  printf("\n");

  num2++ ;

}


return 0;
}

