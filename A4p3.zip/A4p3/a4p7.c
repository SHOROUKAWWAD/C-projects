
/*
JTSK-320111
a4
p1.c
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/

#include <stdio.h>
/*
@brief this program is to add two values by using different function , once by passing variables and another by passing reference
@param a & b are float
@param product() is a function passes values by variables
@param productbyref() is a function passes by reference
*/

float product(float a, float b){

float c;
c=a*b;
printf("%f\n",c);
return 0;

}

void productbyref(float a, float b, float *p){

float G;
p=&G;
*p=a*b;
printf("%f\n",*p);

}
void modifybyref(float *a, float *b){

*a=*a+3;
*b =*b+11;
printf("a=%f b=%f",*a,*b);

}

int main (){


float l;
scanf("%f",&l);
float m;
scanf("%f",&m);

float p;
float *g;
g=&l;
float *f;
f=&m;
float *k;
k=&p;


product(l,m);
productbyref(l,m,k);
modifybyref (g,f);


return 0;
}
