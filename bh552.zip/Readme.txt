======================================================================

KONICA MINOLTA bizhub C652 Series Printer
Printer Software Document                               2010/1/7 Rev.1

======================================================================
This document contains information about the software of this printer.
In addition, the problems that may happen when this printer is used 
and the solutions are mentioned.
Read through this document before you use this printer.

***********************************************************************
 
System Requirements
  Support OS:
    Windows NT Workstation 4.0 (SP6 or later)
    Windows NT Server 4.0 (SP6 or later)
    Windows 2000 Professional (SP4 or later)
    Windows 2000 Server (SP3 or later)
    Windows XP Home Edition (SP2 or later)
    Windows XP Professional (SP2 or later)
    Windows XP Professional x64 Edition
    Windows Server 2003, Standard Edition (SP1 or later)
    Windows Server 2003, Enterprise Edition (SP1 or later)
    Windows Server 2003 R2, Standard Edition
    Windows Server 2003 R2, Enterprise Edition
    Windows Server 2003, Standard x64 Edition
    Windows Server 2003, Enterprise x64 Edition
    Windows Server 2003 R2, Standard x64 Edition
    Windows Server 2003 R2, Enterprise x64 Edition
    Windows Vista Home Basic*
    Windows Vista Home Premium*
    Windows Vista Ultimate*
    Windows Vista Business*
    Windows Vista Enterprise*
    Windows Server 2008 Standard*
    Windows Server 2008 Enterprise*
    Windows 7 Home Basic
    Windows 7 Home Premium*
    Windows 7 Ultimate*
    Windows 7 Professional*
    Windows 7 Enterprise*
    Windows Server 2008 R2 Standard
    Windows Server 2008 R2 Enterprise
    * 32-bit (x86) and 64-bit (x64) editions of Windows are supported.


///////////////////////////////////////////////////////////////////////////////
Attentions and Restrictions when using this printer
///////////////////////////////////////////////////////////////////////////////

  This printer offers many convenient functions.
  Depending on the application, similar functions are realized by itself.
  In such a case, please be careful of the setting method etc.

  Attentions and Restrictions of each functions are shown below.

(1)Paper Size Setting  
  1)When not printing as paper size setting
    - Paper size can be set by the printer property, but it may become invalid 
      the paper size that is specified on the printer property according to 
      the application to use.
      ==> Please set the paper size on the Print menu of the application.
  2)Wide Paper
    When you use a Wide paper, load the paper in the tray and set the paper 
    size in the printer before the printing operation.  
    ==> For the setting procedure, please refer to the User's Guide for the printer.
  3)Registration of Custom Size
    Please perform registration of Custom Size in Windows NT4/2000/XP/VISTA 
    by administrator.  

(2)Paper Tray Setting
  1)Cannot set Paper Tray.
    - To set an optional tray for the Paper Tray, the optional Paper Source unit
      is necessary.  Also, you need to select the Paper Source unit in the Device 
      Option setting of the printer driver.
      ==> Please check the existence of Paper Source unit and the Device Option 
          setting.
    - Paper Tray may have restriction depending on the specified paper size.
  2)When Paper Tray setting doesn't work as specified.
    - Paper Tray can be set by the printer property, but it may become invalid 
      the Paper Tray that is specified on the printer property according to 
      the application to use.
      ==> Please set the Paper Tray on the Print menu of the application.
    - Paper may be fed from the tray other than the specified one depending on 
      the paper size set up on the printer.

(3)Original Orientation Setting
  1)Original Orientation setting doesn't work as specified.
    - Original Orientation can be set by the printer property, but it may become 
      invalid the Original Orientation that is specified on the printer property 
      depending on the application to use.
      ==> Please set Original Orientation in the application.

(4)Collate Functions
  1)Collate doesn't work as specified.
    Collate is able to be set by the printer property, but the following situation
    may occur depending on the application to use if you specify Collate on the
    Print menu.

    - If Combination is specified, the last page of No. n copies
      and the first page of No. n+1 copies are printed on the same paper.
    - If 2-Sided is specified, the first page of No. n+1 copies is printed 
      on 2nd side of the last page of No. n copies.
    - If Booklet is specified, all prints are collected into one book and printed.
    - If Staple is specified, all prints are collected into one set and stapled.
    - If Distribution Control Number is specified, all prints are printed with 
      the same number. 
    - If Secure Print is specified, the waiting documents for print for specified
      number of copies are stored in the printer.
    - If Watermark is specified only on the first page of multiple copies of 
      printing, it will be stamped only on the first page of the first copy.
    - Even if Offset is specified, it will be output without offset.
    ==> Please set No Collate on the Print menu and specify Collate on the printer
        property.

(5)Copies Setting
  1)Copies Setting doesn't work as specified.
    - Copies can be set by the printer property and the Print menu of most of 
      applications, but the priority of setting between the printer property and
      the Print menu is different depending on the application to use.
      ==> First, please set 1 for the copies on the Print menu and specify the 
          required copies by the printer property.
          If only 1 copy is printed with this setting, please specify the required
          copies on the Print menu.
  2)Proof Print and Copies
    - In Microsoft Excel, even though Proof Print function is selected and multiple 
      copies are set for print, all copies of document will be printed without 
      storing.
      *Proof Print function can not be specified with 1 copy.  Also, even if the 
       multiple copies are set in Excel, Proof Print function is cancelled because 
       all data are printed only 1 copy with number of set.
      This can be solved by un-checking [Print on copy unit].

(6)Front Cover / Back Cover
  1)Paper for Front Cover / Back Cover
    When you use Front and/or Back Cover function, it is necessary to set the correct 
    paper beforehand in the Paper Tray for Front and/or Back Cover that is specified 
    by the printer driver.

(7)User Authentication / Account Track
  1)Printing under User Authentication and Account Track
    When you use the printer that requires User Authentication / Account Track before 
    printing, print is not accepted without entering the correct User Name, Department 
    Name and Password.

  2)When the Limitation for printing  is exceeded at the Account Track
    When the Account Track mode and Limitation for printing are enabled in the printer, 
    if there is a job that stops in the middle of printing as the limit is reached, 
    any following jobs are not printed unless the stopping job is canceled.    
    Please ask your administrator to cancel the limitation to output the stopping 
    job or someone must delete the job after confirmation.  

  3)The "Account Track" displayed on the device option displays the status of the 
    ""Account Track" of main body device". Account Track status cannot be displayed on
    the Printer driver when using the Enhanced Server Authentication since the status
    of the ""Account Track" of  Enhanced Server Authentication" could not be acquired.

(8)Booklet and Saddle Stitch
  1)Blank of Paper Center Part
    When Booklet and Saddle Stitch are specified, blank space with a width of about 
    10mm will occur in the center of paper.
    ==> Please make more than 5mm blank space of the original, then print it.
 
(9)Two-way Communication
  1)Acquire Device Information
    When you installed the printer driver to a client computer by Point and Print,
    you can not use [Configure]-[Acquire Device Information] in the printer property.
    ==> Please set the composition of Device Options manually or acquire the option
        information on the server.

  2)About Two-way communication of Printer Driver and MFP
     This printer driver is able to acquire MFP's information via the network communication.
     Please update more than Internet Explorer 6.0 (Service pack 1) to take full
      advantage of this printer driver.
     ==> MFP's information may not be acquired depending on the Internet Explorer version.

(10)OS Restrictions
  1)For using printers installed on Windows 2003 Server as logical printers
    When printers installed on Windows 2003 Server are used as logical printers 
    in client computers and the name of the printers has "/" (slash, ex. 
    "Model1/Model2 PCL"), printing from the client computers (printing to the 
    logical printers in the client computers) may not be done correctly because 
    of restrictions of Windows 2003 Server.
    In this case, printing will be done correctly by renaming the printers 
    so as not to have "/" (ex. "Model1_Model2 PCL"). 
  2)Settings on [Configure]tab on Windows NT4 [* PCL Driver only]
    Settings on [Configure]tab may not be saved.
    ==> Please display [Device Setting]tab to save.
  3)LPR Print on Windows NT4 [* PCL Driver only]
    If printer name or printer queue name of the server are not same as 
    the name or address of the actual server, [Configure]tab -[Acquire Device  
    Information] and [Web Connection] do not work correctly.
  4)Watermark Printing on Windows XP x64
    When printing using 2 or more service packs with 32 bit application,
    Watermark may not be printed by the PCL driver.
    In this case, it can be printed correctly by enabling the following 2 sections settings.
      - Device Property -> Settings"EMF Spool" -> ON
      - Device Property -> Settings"Enable advanced printing features" -> ON
  5)Favorite Setting on Windows 2000 SP4
    When the Printer Driver installed on Windows 2000 SP4 by Point & Print is opened
    via "Property" in the "Print" menu dialog of some applications,
    [Add...] and [Edit...] buttons of Favorite Setting might not be disabled.
    In this case, it is not guaranteed that Favorite Setting works correctly.
  6)Wartermark in PCL driver for x64 Edition
    When printing the document with odd number of pages with specifying "Duplex" and
    "Watermark", a blank page would be added after the last page and the watermark
    would be printed on the blank page.
  7)File name of Phone Book
    Fax driver could not read the Phone Book file with long file or folder name 
    because of the OS's restriction.
  8)Watermark and FAX Cover Sheet on Windows Vista x64
    When printing with Copy Track authentication from 32bit application running 
    on Windows Vista x64, the Watermark and FAX Cover Sheet might not be printed 
    correctly.
  9)FAX Cover Sheet on Windows XP x64
    When printing from 32bit application running on Windows XP x64, the FAX Cover Sheet 
    might not be printed correctly.
 10) Printing PowerPoint Files on Windows XP SP3
    Garbaged characters may appear when printing PowerPoint Files using PS driver on Windows XP SP3.
    To prevent this, in the [Quality] tab of the [Font Settings] dialog, change [Download Font Format] from [Auto] to [Outline].

(11)Others
  1)Screen Font
    When printing with using screen fonts installed in your computer, some of 
    fonts or characters may not be printed correctly.

  2)When sending plural printing jobs to Network Port
    If multiple copies of document is sent to each port such as IPP, SMB, RAW and LPR 
    at the same time. The print out of one set of document may be separated by 
    another print job. 
    ==> In this case, select Uncollated.

  3)Copies Setting in Application
    Some applications may allow you to set copies more than the device's limitation,
    but the printer can not print as specified in the applications.

  4)Blank Page
    According to the application to use, when the data has odd number pages, it may 
    be added the blank paper if 2-Sided function is available.
    In that case, the following phenomenon will occur.
      1)The Watermark will be printed on the last blank page (in case of specifying 
        The Watermark function).
      2)The Overlay will be printed on the last blank page (in case of specifying
        The Overlay function).

  5)Document Name displayed on the panel
    Based on the application that indicates the printing operation of a document, 
    the document name may not be displayed correctly on the panel by the application
    problem.In this case, there is no influence in the printing result.

  6)Orientation and FAX Cover Sheet
    When "Orientation" in the FAX driver is not same as the one set in the application, 
    FAX Cover Sheet might not printed as the preview in the driver showed.


  -----------------------------------------
  Cautions/Restrictions when using a PS driver
  -----------------------------------------

(1)Quality
    When you set [Quality]tab -[Quality Adjustment]-[Detail]-[Photo]-[Pure Black] 
    to Off, the full color counter will be counted up because the device performs 
    CMYK print, but documents will be printed more beautifully.
(2)PostScript Pass through
    Depending on applications to use, some functions of printer drivers might not work
    correctly.  For example, Watermarks specified by printer drivers would be 
    printed in unexpectedly large size when printing from Adobe Photoshop.
    ==> this may be solved by setting [PostScript Pass through] to [Disable] 
        in printer drivers.
    * The following cases are the error samples.
      - Output cannot be performed normally when Adobe Application and Overlay are
        combined.
      - Watermark specified by printer driver may be printed larger than the size
        you specified when printing with Adobe Photoshop.
      - Error page may be printed when printing with the Adobe application.
(3)Banner Printing
    Please set more than 457.4mm / 18.008inch to "Length" in "Custom Size Settings"
    dialog for Banner Printing.
(4)Printing Custom Size Documents
    When printing the document which length and width is the same (i.e. "square"
    shape document) in some application, the device may print the document with
    rotating its direction.
    This means for example that staple or punch may be made in the different 
    position of the document from the expected one.
(5)Overlay Function
    When Overlay, Booklet, and Page Margin we set simultaneously, the leading edge
    of the Overlay will exceed the Page Margin at the time of printing.
    If the Page Margin is set to 10mm, the leading edge of Overlay will be mobed 
    to 15mm.
(6)Printing in the [Auto Color] Setting
    When Black and White document is printed in the [Auto Color] Setting, 
    it may be counted as color document.
    To avoid this situation, change your driver/printer setting and print again.
    (Precondition: [Simulation Profile] is enabled in the printer.)
    Setting changes:
    Printer driver setting: Select [Quality]->[Select Color]->[Gray Scale].
    Printer setting: Select [User Setting]->[Printer Settings]->[PS Settings]
    ->[ICC Profile Settings]->[Simulation Profile]-[None].


  -----------------------------------------
  Cautions/Restrictions when using a XPS driver
  -----------------------------------------
(1) The driver may not be removed in the "Driver" tab of "Server Properties" due to 
    Microsoft XPS. In this case, please delete it after PC reboot.

(2) Printing could not be performed by enabling "Printing directly to the printer."

(3) When the file is outputted with Point&Print, filter function is not available and
    the file is stored by standard setting.

(4) Form could not be created when "Rendering Printing Job with client computer"
    is turned OFF in the sharing Tab of Device Property in Point&Print.


  -----------------------------------------------------
  Cautions and restrictions with specific applications
  -----------------------------------------------------
(1)Microsoft Office
  1)AutoShapes Graphics Print in Office [* PS Driver only]
    If the [Transparency] check box of [Fill] column in [Format AutoShape...]-
    [Colors and Lines]tab is ON, the paint-out part of graphics may not be
    printed correctly at the time of reduction and enlargement print.

  2)Continuous Print by Microsoft Word 2000
    If you print by pressing the print bottom continuously in Microsoft Word 2000, 
    the omission of text and object or the page may occur.  When you print continuously 
    by using the print bottom, set the [Background Printing] check box to ON in 
    [Tools]-[Options]-[Print]tab and then perform printing.
    Or perform the continuous print of same original with setting the Copies to print 
    by using the Print dialog box in [File]-[Print...].

  3)Entire workbook Print in Microsoft Excel
    When you print the Microsoft Excel document that has different binding direction 
    in each sheets with the [Entire workbook] checkbox ON, it may not be printed 
    as you specified.

  4)When you have your computer connect with the printer by SMB under Windows XP and 
    try to print any documents written by Microsoft Word 2002 with Combination and 
    Watermark function, Combination function will not work correctly nor Watermark 
    will be printed in a small font. [* PS Driver only]
     ==> In this case, please print by any communication ports other than SMB.

  5)Duplex Print in Microsoft Word 2007
    When a document with odd number sheet is printed in duplex mode from
    Microsoft Word 2007, 
    white paper which is not included in original may be printed and counted. 

  6)Custom Size printing in Microsoft Word
    When paper size is specified as "Custom Size", it may be printed in invert.
    In this case, it can be printed normally when paper size is specified as
    "Same as Original Size".

  7)Edit Phone Book file at Microsoft Excel
    Please open the Phone Book file with changing the file extension from "csv" 
    to "txt" and specify "character" for each field in order to edit the Phone 
    Book exported from the FAX driver at Microsoft Excel.
    Also please save the Phone Book file edited at Microsoft Excel with selecting 
    "csv" for file type.

  8)Authentication Print in Microsoft Word 2007
    The authentication dialog may not be displayed on the screen during authentication 
    printing.In this case, when you press the ALT key, the authentication dialog will 
    be dispalyed on the screen.

(2)Adobe Acrobat
  1)When a printing is performed from Acrobat Reader or Acrobat, Printing may not 
    be performed normally. 
    ==> Please check the [Print as image] on the Print setting of the application.

  2)Depending on the PDF file, the background may be painted with white out.
    When the topside of this image is printed during overlay print, the downside of the
    image (Original or Overlay) cannot be printed.

  3)When printing the PDF file with turning off the "Choose Paper Source by PDF page 
    size" checkbox in the "Print" dialog, the page with different direction from 
    the 1st page and following pages might not be printed with correct direction 
    since Acrobat Reader will not correctly notify the page direction of pages 
    after the 1st page to the printer driver.

  4)When printing landscape original using Acrobat Reader 9, the page will be rotated 
    first then printed. 
   [*PCL/XPS only]
    This means for example that staple or punch may be made in the different position of 
    the document from the expected one.
    ==> In this case, it can be printed normally when [Auto-Rotate and Center] is specified 
    to OFF in the [Print Setting] of application.

  5)When printing landscape original using Acrobat Reader 9 on Windows XP x64 or 
    Windows Vista x64 SP2, the first page will be printed as portrait original.
    ==>In this case, it can be printed normally when [Auto-Rotate and Center] is specified
    to OFF in the [Print Setting] of application.

(3) Adobe PageMaker, Illustrator
  1)Depending on applications, such as Adobe PageMaker, Illustrator and etc, if it 
    recognizes that it is a PostScript printer driver, the application itself may 
    output PostScript commands. In this case, it may not be printed correctly.
    [* PS Driver only]

  2)When the Illustrator file with paper size A0/A1/B1 is printed with
    Illustrator CS, a part of the image is lost.
    With Illustrator CS2 or more, this problem doesn't occur.

(4) Internet Explorer, Note Pad
  1)Check the selected printer when printing continuously by the Internet Explorer
     or Note Pad.
    Selected printer might differ from the previous selection if several same
     printer drivers have been installed, depending on the application limitation.
     ==>In this case, change the printer driver name with 
        which selection will be changed, to less than 29 characters.

(5)Word97
  1)Unable to print by Word97.
    Word2000 or more is required for the printing by the Word.

(6)Excel
  1)Check the print settings before printing 
    when you print from Excel after switching the printer driver.
    Depending on the limitation of application, 
    current printer driver setting might apply to the printer driver after switching.
    ==>In that case, change the name of a printer driver used to within 29 characters. 

(7)PowerPoint
  1)Please do not enable the following setting when you print from PowerPoint.
    It might cause to hang PowerPoint.
    - "Popup Authentication Dialog when printing" of "Settings" tab.

  2) The background of PowerPoint data is painted with the specified color.
     Because of this, when the topside of this image is printed during the overlay
     print with white background,the bottom of the image (Original or Overlay) cannot
     be printed by combination of the following driver.
      - PowerPoint2003 before ->  PS driver
      - PowerPoint2007 later  ->  PS/PCL driver


* Company names and product names written in this document are the
  registered trademarks or trademarks of their respective companies.

Copyright(C) 2003-2010 KONICA MINOLTA BUSINESS TECHNOLOGIES, INC.
