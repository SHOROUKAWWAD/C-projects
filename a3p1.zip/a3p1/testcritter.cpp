/*
CH08-320142
a3p2.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Critter.h"

int main (){
string newname;
int  boredome1;
int height1;
int hunger1;
string newname2;
int boredome2;



Critter();

cout<<"enter a name"<<endl;

cin >> newname;

Critter((string)newname);

cout << "enter a name:"<<endl;
cin >> newname;
cout <<"enter a boredom rate:"<<endl;
cin >>boredome1;
cout <<"enter Height:"<<endl;
cin >>height1;
cout <<"enter hunger rate:"<<endl;
cin >>hunger1;
// constructor call
Critter(newname,boredome1,hunger1,height1);
cout << "enter a name:"<<endl;
cin >> newname2;
cout <<"enter a boredom rate:"<<endl;
cin >>boredome2;


Critter(newname2,boredome2,2);


return 0;


}
