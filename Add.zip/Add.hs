  
rotate :: Int->[a]->[a]
rotate 0 y = y
rotate 1 y= (tail y)++(take 1 y)
rotate x y= (drop x y) ++ (take x y) 
           
            


            
