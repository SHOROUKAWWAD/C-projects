/*
CH08-320142
a2p6.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Critter.h"

using namespace std;
Critter::Critter() {

}

void Critter::setName(string & newname) {
  name = newname;
}

void Critter::setHunger(int newhunger) {
  hunger = newhunger;
}
void Critter :: setHeight (double newheight){
height = newheight;
}
void Critter :: setBoredom(int newboredom){
boredom = newboredom;
}
void Critter:: setEye(string neweye){
eye = neweye;
}
void Critter::setHair(int newhair){
hair = newhair;
}

void Critter::print() {
  cout << "I am " << name << ". My hunger level is " << hunger << "." << endl;
  cout << "I am " << name << ". My boredom level is " << boredom << "." << endl;
  cout << "I am " << name << ". My height is " << height << "." << endl;
  cout << "I am " << name << ". My hair length is " << hair << "." << endl;
  cout << "I am " << name << ". My eye color is " << eye << "." << endl;

}

int Critter::getHunger() {
  return hunger;
}
double Critter::getHeight(){
return height;
}
int Critter::getBoredom(){
return boredom;
}
string Critter ::getEyer(){
return eye;
}
int Critter::gethair(){
return hair;
}

