/*
CH08-320142
a2
p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
#include <string>
#include "Critter.h"
using namespace std;
int main(int argc, char** argv)
{
	Critter c;

	string name;
	int hunger;
	int boredom;
	double height;
	string eye;
	int hair;

	cout << endl << "Please enter data: " << endl;
	cout << "Name: ";
	getline(cin, name);//assigning value of variable to getters
	c.setName(name);
	cout << "Hunger: ";
	cin >> hunger;//taking value from the user
	c.setHunger(hunger);
    cout <<"Height: ";
    cin >> height;
    c.setHeight(height);
    cout << "Boredom: ";
    cin >> boredom;
    c.setBoredom(boredom);
    cout <<"Eye color: ";
    getline(cin, eye);
	c.setName(eye);
	cout << "hair length: ";
	cin >>hair;
	c.setHair(hair);

	cout << "You have created:" << endl;
	c.print();
        return 0;
}
