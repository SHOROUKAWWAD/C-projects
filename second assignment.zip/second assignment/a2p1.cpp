/*
CH08-320142
a2
p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/

#include <iostream>
using namespace std ;
int n;

int myfirst(int array1[], int n){//function works with the integers and gives the first even positive number
for (int i=0; i<n;i++){

    if ((array1[i]%2)==0&&array1[i]>0){
        return array1[i];
    }

}
return -1;
}
double  myfirst (double array2[], int n ){//function works with doubles and gives the first double number without fractions

for (int i=0; i<n; i++){
  if (array2[i]<0&& (int)array2[i]== array2[i]){
        return array2[i];

  }

}
return -1.1;
}

char myfirst (string array3){//function works with strings and gives the first consonant

for (int i=0; i<n; i++){

    if (array3[i]!='a'&&array3[i]!='A'&& array3[i]!='e'&&array3[i]!='E'&&array3[i]!='i'&& array3[i]!='I'&&array3[i]!='o'&&array3[i]!='O'&&array3[i]!='u'&&array3[i]!='U'){


        return array3[i];
    }


}

return '0';

}





 int main (){

  cout << "enter the number of elements";
  cin >>n;


cout << "enter array of integers";

 int array1[n];
 for (int i=0; i<n; i++){
    cin >> array1[i];
    }


 cout << "enter array of doubles";

 double array2[n];

 for (int i=0 ; i<n ; i++){
  cin >> array2[i] ;
    }

 cout << "enter a string";
 string array3;
 cin >> array3;


 // calling the functions

 /*myfirst (array1,n);
 myfirst (array2,n);
 myfirst (array3);*/

 cout <<"the return value for the integers: "<< myfirst (array1,n)<<endl;
 cout <<"the return value for the doubles: "<< myfirst (array2,n)<<endl;
 cout <<"the return value for the strings: "<< myfirst (array3)<<endl;















 return 0;
 }
