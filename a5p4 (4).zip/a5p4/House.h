/*
CH08-320143
a5p5.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#ifndef HOUSE_H
#define HOUSE_H
#include "Genericplayer.h"
class House : public GenericPlayer
{
public:
    House(const string& name = "House");

    virtual ~House();

    //indicates whether house is hitting - will always hit on 16 or less
    virtual bool IsHitting() const;

    //flips over first card
    void FlipFirstCard();
};


#endif // HOUSE_H
