/*
CH08-320143
a5p5.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#ifndef GAME_H
#define GAME_H

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include "Deck.h"
#include "House.h"
#include "Player.h"
using namespace std;
class Game
{
public:
    Game(const vector <string> & names);

    ~Game();

    //plays the game of blackjack
    void Play();

private:
    Deck m_Deck;
    House m_House;
    vector<Player> m_Players;
};


#endif // GAME_H
