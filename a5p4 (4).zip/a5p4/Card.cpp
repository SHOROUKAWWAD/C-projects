/*
CH08-320143
a5p5.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Card.h"

Card::Card(rank r, suit s, bool ifu):  m_Rank(r), m_Suit(s), m_IsFaceUp(ifu)
{}


void Card::Flip()
{
    m_IsFaceUp = !(m_IsFaceUp);
}

int Card::GetValue() const
{
	int value;
	if (!m_IsFaceUp) {
		value = 0;
	}
	else {
		if (m_Rank < 11) {
			value = m_Rank;
		}
		else {
			value = 10;
		}
	}
	return value;
}
