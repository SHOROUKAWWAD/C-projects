/*
CH08-320143
a5p5.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Hand.h"
#include "Card.h"
Hand::Hand()
{
    m_Cards.reserve(7);
}

Hand::~Hand()
{
    Clear();
}

void Hand::Add(Card* pCard)
{
    m_Cards.push_back(pCard);
}

void Hand::Clear()
{
    //iterate through vector, freeing all memory on the heap
    vector<Card*>::iterator iter = m_Cards.begin();
    for (iter = m_Cards.begin(); iter != m_Cards.end(); ++iter)
    {
        delete *iter;
        *iter = 0;
    }
    //clear vector of pointers
    m_Cards.clear();
}


int Hand::GetTotal() const
{
	int total = 0;
	vector<Card*>::const_iterator it;
	for (it = m_Cards.begin(); it != m_Cards.end(); it++) {
		if ((*it)->GetValue() == 1) {
			if (total <= 10) {
				total += 11;
			}
			else {
				total += 1;
			}
		}
		else {
			total += (*it)->GetValue();
		}
	}
	return total;
}
