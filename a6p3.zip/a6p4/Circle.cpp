/*
CH08-320142
a6-p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
#include <cmath>
#include "Circle.h"

Circle::Circle(const char *n, double a) : Area(n) {
	radius = a;

}

Circle::~Circle() {
}

double Circle::calcArea() const {
    cout << "CIRCLE WAS CALLED: \n";
	std::cout << "calcArea of Circle..."<<radius * radius * M_PI<<endl ;
	return radius * radius * M_PI;
}
double Circle :: calcPerimeter()const {
std::cout << "calcPerimeter of Circle..."<<radius *2*M_PI<<endl;

return radius *2*M_PI;
}
