/*
CH08-320142
a6-p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"
 /*     |-->Rectangle -->square
 Area ->|
        |--> circle --> ring
 */
const int num_obj = 7;
int main() {
	Area *list[num_obj];						// declaring an array of 6 area-type objects.
	int index = 0;								// declaring a counter for summing up the areas
	double sum_area = 0.0;                      // initiating the sum of the areas to 0
	double sum_Peri =0.0;
	cout << "Creating Ring: ";
	Ring blue_ring("BLUE", 5, 2);				// calling the parametric constructor for Ring class
	cout << "Creating Circle: ";
	Circle yellow_circle("YELLOW", 7);
	cout << "Creating Rectangle: ";
	Rectangle green_rectangle("GREEN",5,6);
	cout << "Creating Circle: ";
	Circle red_circle("RED", 8);
	cout << "Creating Rectangle: ";
	Rectangle black_rectangle("BLACK", 10, 20);
	cout << "Creating Ring: ";
	Ring violet_ring("VIOLET", 100, 5);
	 cout <<"Creating Square: ";
    Square red_square ("RED",20);
	list[0] = &blue_ring;   /* assigning the called shapes to each element of the areas' array \
	                                            assigning  the object blue ring to the first element of the array*/

	list[1] = &yellow_circle;
	list[2] = &green_rectangle;
	list[3] = &red_circle;
	list[4] = &black_rectangle;
	list[5] = &violet_ring;
	list[6] = &red_square;
	while (index < num_obj) {					/*  while loop to print out the color of the shapes and
                                         compute the sum of the areas of the shapes */
		(list[index])->getColor();
		double perimeter = list[index]->calcPerimeter();//perimeter calculated
		double area = list[index++]->calcArea();// assigning the return value of the function calcArea to double variable for each element in list
		sum_area += area;
		sum_Peri +=perimeter;
	}
	cout << "\nThe total area is "
			<< sum_area << " units " << endl;	//  printing the sum of the areas on the screen after terminating the loop
    cout << "The total perimeter is "
              <<sum_Peri<<"units"<<endl;
	return 0;
}
