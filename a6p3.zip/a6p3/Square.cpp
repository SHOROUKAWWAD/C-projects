/*
CH08-320142
a6-p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Square.h"
#include <iostream>
using namespace std;
Square::Square (const char *n,  double b):Rectangle(n,b,b)
{
   side = b;
   cout << "Square has been called...";
}

double Square::calcArea()const{
std::cout << "calcArea of Square...";
	return side*side;
}
double Square::calcPerimeter()const{
std::cout << "calcPerimeter of Square...";
   return 4*side;
}
Square::~Square()
{
    //dtor
}
