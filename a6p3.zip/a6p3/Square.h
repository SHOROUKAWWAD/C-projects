/*
CH08-320142
a6-p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#ifndef SQUARE_H
#define SQUARE_H

#include "Rectangle.h"

class Square: public Rectangle
{
    public:
        Square (const char *n,  double b);
        double calcArea() const ;
        double calcPerimeter()const ;
        virtual ~Square();

    protected:

    private:
        double side;
};

#endif // SQUARE_H
