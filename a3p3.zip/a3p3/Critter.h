/*
CH08-320142
a3p2.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#ifndef CRITTER_H
#define CRITTER_H
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

class Critter
{
    public://declaration
        Critter();
        Critter (string na);
        Critter (string n, int b, int hu, int h=10);

        virtual ~Critter();

    protected:

    private:
     string name;
     double hunger;
     double boredom;
     double height;
};

#endif // CRITTER_H
