/*
CH08-320142
a3p2.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Critter.h"

Critter::Critter()
{
  cout << "first constructor was called "<<endl;
        name ='0';
        hunger = 0;
        boredom = 0;
        height =5;
        cout <<"name:"<<name<<"\n hunger: "<<hunger<<"\n boredom: "<< boredom<<"\n height: "<<height<<endl;  //ctor
}

Critter::Critter (string na): name(na){
        hunger = 0;
        boredom = 0;
        height =0;
        cout << "second constructor was called"<<endl;
        cout <<"name:"<<name<<"\n hunger: "<<hunger<<"\n boredom: "<< boredom<<"\n height: "<<height<<endl;

        }



Critter::Critter (string n , int b, int hu, int h) {
        name =n;
        boredom=b;
        hunger =hu;
        height = h;
        cout <<"third constructor was called"<<endl;
        cout <<"name:"<<name<<"\n hunger: "<<hunger<<"\n boredom: "<< boredom<<"\n height: "<<height<<endl;
        }

Critter::~Critter()
{

}
