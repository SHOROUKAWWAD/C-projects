// please refer to shapes.h for methods documentation
/*
CH08-320142
a5
p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
#include "Shapes.h"

using namespace std;

Shape::Shape(const string& n) : name(n) {
}

void Shape::printName() const {
	cout << name << endl;
}

CenteredShape::CenteredShape(const string& n, double nx, double ny): Shape(n) {
	x = nx;
	y = ny;
}

RegularPolygon::RegularPolygon(const string& n, double nx, double ny, int nl) :
	CenteredShape(n,nx,ny)
{
	EdgesNumber = nl;
}

Circle::Circle(const string& n, double nx, double ny, double r) :
  CenteredShape(n,nx,ny)
{
	Radius = r;
}
// parametric constructor
Hexagon :: Hexagon (const std::string& n, double Xn, double Yn, double s,std:: string c):
     RegularPolygon(n,Xn,Yn,6){
         cout << "creating a Hexagon with color: "<<c<< "  and side length: "<< s<<endl;
     side =s;
     color =c;

     }
Hexagon :: Hexagon( const Hexagon& obj):RegularPolygon(obj.name, obj.x,obj.y,6){
cout << "/n /n the copy constructor was called /n  the following Hexagon is a copy of the second one:\n ";
side = obj.side;
color = obj.color;

}
    void  Hexagon :: setSide(double s){

side = s;
    }
    void Hexagon::setColor (std::string c) {
    color =c;
    }
    double Hexagon:: getSide (){
    return side;
    }
    std::string Hexagon:: getColor (){
    return color;
    }

    double Hexagon :: area(){
    double area = 3*sqrt(3)/2*pow(side,2);
    cout << "the area of the Hexagon: "<< area<<endl;
     return area;
    }
    double Hexagon :: Perimeter (){
    double p = 6*side;

    cout << "the perimeter of the Hexagon: "<< p<<endl;
     return p;
    }
    Hexagon :: Hexagon ():RegularPolygon(name,x,y,6){}
    void Hexagon:: print(){
    cout << "the side length of the hexagon: "<<side<<endl;
    cout << "the color of the Hexagon: "<<color<<endl ;



    }

