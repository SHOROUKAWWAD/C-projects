/*
CH08-320142
a5
p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
#include "Shapes.h"
int main (){
//first constructor
Hexagon b ("firs Hexagon",3,2,9,"blue");
b.print();
b.area();
b.Perimeter();
//second constructor
Hexagon a ("second Hexagon",3,4,15,"green");
a.print();
a.area();
a.Perimeter();
//copy constructor
std::cout << "\n a copy of the second constructor:\n ";
Hexagon* str = new Hexagon[1];
*str = a;
str[0].print();
str[0].area();
str[0].Perimeter();













return 0;
}
