/*
CH08-320142
a4p6.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#ifndef VECTOR_H
#define VECTOR_H
#include <iostream>
#include <cmath>

using namespace std;

class Vector {
        public:
                Vector();
        Vector(double, double * );
        Vector(Vector & obj);
        void setValue(double);
        void setPointer(double * );
        double getValue();
        double getPointer();
        double norm(double, double);
        double scalar(double, double, double, double);
        void sum(double, double, double, double);
        void diff(double, double, double, double);
        void print();
        virtual~Vector();

        protected:

                private:
                double value;
        double * ptr;
        /*double valuee;
        double *ptrr;
        double valueee;
        double *ptrrr;*/

};

#endif // VECTOR_H
