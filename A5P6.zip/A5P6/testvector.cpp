/*
CH08-320142
a4p6.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
#include "Vector.h"
using namespace std;

int main() {
//declaring variables
        double * ptr1;
        double pointer;
        double value1;
        double x;
        double y;
        double z;
        double v;

        ptr1 = & pointer;

        cout << "enter I part for the first vector: ";
        cin >> value1;
        cout << "enter j part for the first vector: ";
        cin >> pointer;
      //first vector default
        Vector * a = new Vector;
        a[0].setValue(value1);
        a[0].setPointer(ptr1);
        a[0].print();
        x = a[0].getPointer();
        y = a[0].getValue();
        a[0].norm(y, x);
        //second vector
        //copy constructor
        cout << "\n about to call the copy constructor\n";
        Vector d = * a;
       // cout << "the second copied vector: ";
        //d.print();

        cout << "enter I part for the third vector:\n";
        cin >> value1;
        cout << "enter j part for the third vector :\n";
        cin >> pointer;
   //third vector
        Vector * b;
        b = new Vector(value1, ptr1);
        b[0].print();
        z = b[0].getPointer();
        v = b[0].getValue();
        b[0].sum(y, x, v, z);
        b[0].diff(y, x, v, z);
        b[0].scalar(y, x, v, z);

        delete[] a;
        delete[] b;

}
