/*
CH08-320142
a4p6.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Vector.h"
//default
Vector::Vector() {

        //ctor
}
//parametric
Vector::Vector(double value1, double * ptr1) {

        ptr = new double;
        value = value1;
        ptr = ptr1;
}
//copy constructor
Vector::Vector(Vector & obj) {

        value = obj.value;
        ptr = obj.ptr = new double;

        cout << "copy constructor was called" << endl;
}
//setters and getters
void Vector::setValue(double newvalue) {
        value = newvalue;
}
void Vector::setPointer(double * newpointer) {
        ptr = newpointer;
}
double Vector::getValue() {
        return value;
}
double Vector::getPointer() {
        return *ptr;
}

void Vector::print() {
        cout << value << "i" << "  " << showpos << * ptr << "j" << endl;

}
double Vector::norm(double x, double y) {
        double z;
        z = sqrt(y * y + x * x);
        cout << "the norm of the first vector: " << z << endl;
        return z;
}

//sum
void Vector::sum(double s1, double s2, double r1, double r2) {
        double z = s1 + r1;
        double c = s2 + r2;
        cout << "the sum of the two vectors: " << z << "i" << showpos << c << "j" << endl;

}
//scalar product
double Vector::scalar(double s1, double s2, double r1, double r2) {
        double z = s1 * r1 + s2 * r2;

        cout << "the scalar product of the two vectors: " << z;
        return z;

}
//difference
void Vector::diff(double s1, double s2, double r1, double r2) {

        double z = s1 - r1;
        double c = s2 - r2;
        cout << "the difference between the two vectors: " << z << "i" << showpos << c << "j" << endl;

}

Vector::~Vector() {
        delete[] ptr;

        //dtor
}
