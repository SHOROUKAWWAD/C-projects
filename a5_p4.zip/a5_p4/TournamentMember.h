/*
CH08-320142
a5-p2.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/

#ifndef TOURNAMENTMEMBER_H
#define TOURNAMENTMEMBER_H
#include <string>
#include <iostream>
#include<cstring>
#include<ctime>
#include<cstdlib>

using namespace std;

class TournamentMember
{
    public:
        TournamentMember();
        TournamentMember(char*c,char*s,char* nu ,char* a,char* d);
        TournamentMember(TournamentMember&);
        void print();//print method definition
        void changelocation(string l);//location method definition

//punch of setters and getters
        void setFirst(char* name ){
*firstname = name;
}
        void setSecond(char* name ){
*lastname = name;
}

        void setDate(char*d){
*date = d;
}


        void setHeight (char*n){
*height =n;
}
        void setAge(char*a){
*age=a;
}

//punch of getters
        string getFirst(){
return *firstname;
}
        string getSecond(){
return *lastname;
}
        string getDate(){
return *date;
}
        string getHeight (){
 return *height;
}
        string getAge(){
  return *age;
}


        ~TournamentMember();

 protected:
static string locations;
    private:
    //declaring variables

    char* firstname [36];
    char* lastname [36];
    char* date[11];
    char* height[3];
    char* age[3];
};

class Player:public TournamentMember{

public:
   void setNumber(int n){
   number =n;
   }
   void setGoals(int g){
   goals =g;
   }
   void setPosition(string p){
   position =p;
   }
   void setFoot(string f){
   foot =f;
   }
   int getNumber (){
   return number;
   }
   int getGoals (){
   return goals;
   }
   string getPosition(){
   return position;
   }
   string getFoot(){
   return foot;
   }
    void print();
    void increment();
   Player();
   Player(char*,char*,char*,char*,char*,int, int,string,string);
   Player(Player&);

private:

int  number;
int goals;
string position;
string foot;

};
//
class Referee: public TournamentMember {
        public: Referee() {

        }

        bool addToRedCardList(Player * p) {

                bool on_list = false; //boolean variable
                int k;
                for (int i = 0; i < yellowcardcount; i++) {
                        k = i;
                        if (yellowCardList[k] == p) { //if the player exists on the yellow list
                                on_list = true;

                                for (int j = 0; j < (yellowcardcount - 1); j++) {
                                        yellowCardList[j] = yellowCardList[j + 1];

                                        // add him to the red
                                }

                                redCardList[redcardcount] = yellowCardList[k];
                                yellowcardcount--;
                                redcardcount++;
                                cout << "the player has been added to the red card list" << endl;
                                return true;

                        }
                }
                if (!on_list) {
                        //if not, add him to the yellow

                        addToYellowCardList(p);

                        return false;
                }
                return false;
        }

        bool on_the_redlist = false; //boolean variable

        bool addToYellowCardList(Player * p) {


                for (int i = 0; i < redcardcount; i++) {



                        if (redCardList[i] == p) { //if the player exists on the red list, return false
                                on_the_redlist = true;
                                cout << "the player does exist on the red list\n" << endl;
                                return false;

                        }

                }
                if (!on_the_redlist) { //if not

                        cout << "the player has been added to the yellow card list" << endl;
                        yellowCardList[yellowcardcount] = p;
                        yellowcardcount++;
                        return true;

                }
                return false;
        }

        private:

                int yellowcardcount = 0;
        int redcardcount = 0;
        Player * yellowCardList[40];
        Player * redCardList[40];

};

#endif // TOURNAMENT_H
