#include "TournamentMember.h"
#include<ctime>

int main(){

     char* d= new char[11];
     char* c = new char[36];
     char* s = new char[36];
     char* nu = new char[36];
      char* a= new char[36];
      int n;
      int o;
      string p;
      string q;

    cout <<"FIRST PLAYER:\n";
    cout <<"enter the first name:\n";

    cin >>c;
    cout << "enter the last name: \n";

    cin >>s;

    cout <<"enter the player height:\n";

    cin >>nu;
    cout <<"enter the age of the player: \n";

    cin >>a;
    cout <<"enter the date of birth: \n";

    cin >>d;

    cout << "enter the number of the player:\n";

    cin >>n;

    cout << "enter the number of goals:\n";

    cin >>o;

    cout << "enter the position of the player: \n";

    cin >>p;

    cout << "enter whether the player was right footed or left footed: \n";

    cin >>q;




Player x (c,s,nu,a,d,n,o,p,q);

x.increment();
cout <<"SECOND PLAYER:\n";
cout <<"enter the first name:\n";

    cin >>c;
    cout << "enter the last name: \n";

    cin >>s;

    cout <<"enter the player height:\n";

    cin >>nu;
    cout <<"enter the age of the player: \n";

    cin >>a;
    cout <<"enter the date of birth: \n";

    cin >>d;

    cout << "enter the number of the player:\n";

    cin >>n;

    cout << "enter the number of goals:\n";

    cin >>o;

    cout << "enter the position of the player: \n";

    cin >>p;

    cout << "enter whether the player was right footed or left footed: \n";

    cin >>q;
Player y (c,s,nu,a,d,n,o,p,q);
//Player y ;

y.increment();

cout <<"THIRD PLAYER:\n";

cout <<"enter the first name:\n";

    cin >>c;
    cout << "enter the last name: \n";

    cin >>s;
    /*cout << "enter the location: \n";
    string  l;
    cin >>l;*/
    cout <<"enter the player height:\n";

    cin >>nu;
    cout <<"enter the age of the player: \n";

    cin >>a;
    cout <<"enter the date of birth: \n";

    cin >>d;

    cout << "enter the number of the player:\n";

    cin >>n;

    cout << "enter the number of goals:\n";

    cin >>o;

    cout << "enter the position of the player: \n";

    cin >>p;

    cout << "enter whether the player was right footed or left footed: \n";

    cin >>q;

 Player z (c,s,nu,a,d,n,o,p,q);

 z.increment();

 cout << "information for the first player:\n";
 x.print();
cout << "information for the second player:\n";
 y.print();
cout << "information for the third player:\n";
 z.print();

 cout << "enter the location: \n";
    string  l= "Hamburg";
 x.changelocation(l);

 cout << "\n\ninfo after changing the location:\n\n";

cout << "information for the first player:\n";
 x.print();
cout << "information for the second player:\n";
 y.print();
cout << "information for the third player:\n";
 z.print();


 Referee v;
/* v.addToRedCardList(&y);
 v.addToYellowCardList(&y);
 v.addToRedCardList(&x);
 v.addToYellowCardList(&y);*/
srand(time(0));
 Player array[3];//list of players
 array[0]=x;
 array[1]=y;
 array[2]=z;
 //int N;

 for (int i=0; i<10; i++){
//testing random players
   v.addToRedCardList(&array[rand()%2]);

 }



delete[]c;
delete[]s;
delete[]nu;
delete[]a;
delete[]d;

}
