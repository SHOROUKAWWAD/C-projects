/*
CH08-320142
a5-p2.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/

#include "TournamentMember.h"
string TournamentMember::locations ="Bremen";
//parametric constructor
TournamentMember::TournamentMember(char*c,char*s,char* nu ,char* a,char* d){

        *firstname =c;
        *lastname=s;
        *height =nu;
        *age =a;
        *date=d;
}

TournamentMember::TournamentMember(){
  //cout << "COPY CONSTRUCTOR WAS CALLED\n";
}
//copy constructor
TournamentMember::TournamentMember(TournamentMember &obj){

*firstname = obj.firstname[36];
locations= obj.locations;
*lastname=obj.lastname[36];
*age=obj.age[3];
*height = obj.height[3];
*date=obj.date[11];
}

void TournamentMember::changelocation(string l){
        locations =l;
}
//print method
void TournamentMember::print(){
cout <<"first name: " <<*firstname<<endl;
cout <<"last name: "<<*lastname<<endl;
cout<<"location: "<<locations<<endl;
cout <<"age: "<<*age<<endl;
cout << "height: "<<*height<<endl;
cout << "date: "<<*date<<endl;
}
   Player:: Player(){

            //cout << "DEFAULT CONSTRUCTOR WAS CALLED\n";
   }
   Player::Player(char*a,char*b,char*c,char*d,char*e,int f, int g,string h,string i):
       TournamentMember(a,b,c,d,e){
           cout << "PARAMETRIC CONSTRUCTORWAS CALLED\n";
   number =f;
   goals =g;
   position=h;
   foot=i;
   }


   Player::Player(Player&obj){
   cout <<"COPY ONSTRUCTOR WAS CALLED"<<endl;
   number = obj.number;
   goals  = obj.goals;
   position = obj.position;
   foot  = obj.foot;

   }

   void Player::print(){
cout <<"first name: " <<getFirst()<<endl;
cout <<"last name: "<<getSecond()<<endl;
cout<<"location: "<<locations<<endl;
cout <<"age: "<<getAge()<<endl;
cout << "height: "<<getHeight()<<endl;
cout << "date: "<<getDate()<<endl;
cout << "player number: "<<getNumber()<<endl;
cout <<"number of goals: "<<goals<<endl;
cout << "player's position: "<<getPosition()<<endl;
cout << "foot: "<<getFoot()<<endl;


   }
   void Player::increment (){
   goals++;
   cout <<"new score: "<<goals<<endl;
   }





TournamentMember::~TournamentMember(){


}
