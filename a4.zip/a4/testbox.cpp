/*
CH08-320142
a4p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Box.h"

using namespace std;

int main()
{
  double D;
  double W;
  double H;

    Box *boxes;
   int n;
   cout << "enter an integer"<<endl;
   cin>>n;
   cout << "enter the dimensions of the boxes"<<endl;
  boxes = new Box[2*n];

  for (int i=0; i<n; i++){
      cin >>D;
    boxes[i].setDepth(D);
      cin >>H;
    boxes[i].setHeight(H);
     cin >> W;
    boxes[i].setWidth(W);
    boxes[n+i] = Box(boxes[i]);
  }
  for (int i=0; i<2*n; i++){
    boxes[i].print();
  }
delete[]boxes;
return 0;
}
