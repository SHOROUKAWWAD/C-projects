/*
CH08-320142
a4p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Box.h"
//default
Box::Box() {
  height = 1;
  depth = 1;
  width = 1;
}
//setter
Box::Box(double d, double w, double h) {

  height = h;
  width = w;
  depth = d;
  volume = height * width * depth;
  cout << "the volume of the box is: " << volume << endl;
  //ctor
}
Box::Box(const Box & obj) {
  height = obj.height;
  width = obj.width;
  depth = obj.depth;
  volume = obj.volume;
}
//setters
void Box::setDepth(double newdepth) {
  depth = newdepth;
}
void Box::setHeight(double newheight) {
  height = newheight;
}
void Box::setWidth(double newwidth) {
  width = newwidth;
}

void Box::setSize() {
  volume = height * width * depth;

}
//getter
double Box::getSize() {
  return volume;
}
//print
void Box::print() {
    Box::setSize();
  cout << "the volume:" << volume << endl;
}

Box::~Box() {
  //dtor
}
