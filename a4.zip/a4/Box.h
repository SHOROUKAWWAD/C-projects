/*
CH08-320142
a4p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#ifndef BOX_H
#define BOX_H
#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

class Box
{
    public:
        Box();
        Box (double , double, double);
        Box (const Box&);
        void setDepth(double newdepth);
        void setWidth (double newwidth);
        void setHeight (double newheight);
        void setSize();
        double getHeight();
        double getWidth ();
        double getDepth ();
        double getSize();

        void print();

        virtual ~Box();

    protected:

    private:

      double width;
      double height;
      double depth;
      double volume;
};

#endif // BOX_H
