/*
CH08-320142
a6-p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include "Square.h"
#include <iostream>
using namespace std;
Square::Square (const char *n,  double b):Rectangle(n,b,b)
{
    side = b;

}

double Square::calcArea()const{
    cout << "SquareWas called:\n";
std::cout << "calcArea of Square..." <<side*side<<endl;
	return side*side;
}
double Square::calcPerimeter()const{
std::cout << "calcPerimeter of Square..."<<4*side<<endl;
   return 4*side;
}
Square::~Square()
{
    //dtor
}
