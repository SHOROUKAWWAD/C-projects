/*
CH08-320142
a6-p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"
#include <cstdlib>
#include <ctime>
//random color generator
char * randcolor() {

        char * color[4];
        color[0] = "RED";
        color[1] = "BLACK";
        color[2] = "BLUE";
        color[3] = "VIOLET";

        char * randcolor = color[rand() % 4];
        return randcolor;
}

int main() {

        srand(time(0));
//declaring numbers
        double n1;
        double n2;

        for (int i = 0; i < 25; i++) {
                // two random number generators
                cout << i + 1 << "-" << endl;
                n1 = (rand() % 95) + 5;
                n2 = (rand() % 95) + 5;

                char * f = randcolor();

                Rectangle a(randcolor(), n1, n2);
                Circle b(randcolor(), n1);
                Ring c(randcolor(), n1, n2);
                Square d(randcolor(), n1);

                Area * list[4];
                list[0] = & a;
                list[1] = & b;
                list[2] = & c;
                list[3] = & d;

                cout << "THECOLOR OF THE SHAPE :" << * f << endl;

                int n = rand() % 4;
                list[n];
                list[n] -> calcArea();
                list[n] -> calcPerimeter();

        }

}
