/*
CH08-320143
a6_p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
 */

#include <iostream>
#include <cstdlib>
#include "fraction.h"
#include <string>
using namespace std;

 string msgexception = "Invalid data or logical error";

Fraction::Fraction(int n, int d)
{
    int temp = gcd(n,d);
    num = n/temp;
    den = d/temp;
    if (den==0)
    {
        throw msgexception;
    }
}

Fraction::Fraction()
{
    num = 1;
    den = 1;
}

Fraction::Fraction(const string s)
{

    int l = s.length();
    string str;
    for(int i=0; i<l; i++){
        if(s[i] == '/'){
            num=atoi(str.c_str());
            str = "";
        }
        else
            str = str + s[i];
    }
    den = atoi(str.c_str());
    int tmp_gcd=gcd(num,den);
    if(den == 0)
        throw msgexception;
    else{
        num = num / tmp_gcd;
        den = den / tmp_gcd;
    }

}

Fraction::Fraction(const Fraction &x)
{
    num = x.num;
    den = x.den;
    //exception
    if (den==0)
    {
        throw msgexception;
    }
}
//setters
void Fraction::setnum(int newnum)
{
    num = newnum;
}

void Fraction::setden(int newden)
{
    den = newden;
}

void Fraction::setstring(string s)
{
    msgexception = s;
}
//getters
int Fraction::getnum()
{
    return num;
}

int Fraction::getden()
{
    return den;
}

string Fraction::getstring()
{
    return msgexception;
}
//overloading
bool Fraction::operator<(const Fraction &x)
{
    if((num*lcm(den,x.den)/den) < (x.num*lcm(den,x.den)/x.den))
        return true;
    else
        return false;
}

bool Fraction::operator<=(const Fraction &x)
{
    if((num*lcm(den,x.den)/den) <= (x.num*lcm(den,x.den)/x.den))
        return true;
    else
        return false;
}

bool Fraction::operator>(const Fraction &x)
{
    if((num*lcm(den,x.den)/den) > (x.num*lcm(den,x.den)/x.den))
        return true;
    else
        return false;
}

bool Fraction::operator>=(const Fraction &x)
{
    if((num*lcm(den,x.den)/den) >= (x.num*lcm(den,x.den)/x.den))
        return true;
    else
        return false;
}

bool Fraction::operator==(const Fraction &x)
{
    if((num == x.num) && (den == x.den))
        return true;
    else
        return false;
}
Fraction Fraction::operator *(Fraction &x)
{
    Fraction f(num*x.num,den*x.den);
    return f;
}

bool Fraction::operator!=(const Fraction &x)
{
    if((num != x.num) || (den != x.den))
        return true;
    else
        return false;
}


Fraction Fraction::operator+(Fraction &x)
{
    int l = lcm(den, x.den);
    Fraction f1(((num*l)/den)+(x.num*l/x.den),l);
    return f1;

}


Fraction Fraction::operator-(Fraction &x)
{
    int l = lcm(den, x.den);
    Fraction f2(((num*l)/den)-(x.num*l/x.den),l);
    return f2;

}



Fraction Fraction::operator /(Fraction &x)
{
    Fraction f(num*x.den,den*x.num);
    return f;
}
int Fraction::gcd(int a,int b)
{
    int result = 1;
    for(int j=1;j<=a && j<=b;j++)
    {
        if(a%j == 0 && b%j == 0)
            result = j;
    }
    return result;
}

Fraction& Fraction::operator=(Fraction &x)
{
    num = x.num;
    den = x.den;
    if (den==0)
    {
        throw msgexception;
    }
    return *this;
}

ostream &operator<<(ostream &out,const Fraction &x){
    if(x.num==0)
        return out;

    out << x.num << "/" << x.den << endl;
    return out;
}

istream &operator>>(istream &in, Fraction &x)
{
    in >> x.num;
    in >> x.den;
    int tmp_gcd = x.gcd(x.num,x.den);
    if(x.den==0)
        throw msgexception;
    else
    {
        x.num=x.num/tmp_gcd;
        x.den=x.den/tmp_gcd;
    }

    return in;
}





int Fraction::lcm(int x,int y)
{ return (x*y) / gcd(x,y); }


