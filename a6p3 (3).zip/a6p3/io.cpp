/*
CH08-320143
a6p4.cpp
SHOROUK AWWAD
s.awwad@jacobs-university.de
*/

#include <iostream>
#include "fraction.h"
using namespace std;
int p = 0;
int f = 0;
void test(bool t) {
    if (t)
        p++;
    else
        f++;
}
int main()
{

    Fraction x(1,2);
    int lol,lol2;
    cout << "Input fraction a: ";
    cin >> lol>> lol2;
    Fraction y(lol,lol2);
    test(y == x);

    cout << "Operators' test" << endl;
    cout << "Passed: " << p << " tests" << endl << "Failed: " << f << " tests" << endl;


    return 0;

}




