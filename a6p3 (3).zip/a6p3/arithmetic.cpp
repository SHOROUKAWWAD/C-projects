/*
CH08-320143
a6_p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
 */
#include <iostream>
#include "fraction.h"
using namespace std;
int p = 0;
int f = 0;
void test(bool t) {
    if (t)
        p++;
    else
        f++;
}

int main()
{
    Fraction a(1,2);
    Fraction b(2,5);
    Fraction c(9,10); //addition of a and b
    Fraction d(1,10); //subtraction of a and b
    Fraction e(2,10); //multiplication of a and b
    Fraction m(5,4); //divison of a and b
    test((a+b) == c);
    test((a-b) == d);
    test((a*b) == e);
    test((a/b) == m);
    cout << "Operators' test" << endl;
    cout << "Passed: " << p << " tests" << endl << "Failed: " << f << " tests" << endl;
    return 0;
}
