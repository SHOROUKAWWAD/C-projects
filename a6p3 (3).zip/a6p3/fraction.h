/*
 CH08-320143
a6_p3.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de
 */
#include <iostream>
#ifndef fraction_h
#define fraction_h

class Fraction
{
private:
    int num;
    int den;
    int gcd(int a, int b);
    int lcm(int a, int b);
public:
    Fraction();
    Fraction(int,int);
    Fraction(const std::string);
    Fraction(const Fraction&);
    void setnum(int newnum);
    void setden(int newden);
    void setstring(std::string newstring);
    int getnum();
    int getden();
    std::string getstring();
    bool operator<(const Fraction&);
    bool operator<=(const Fraction&);
    bool operator>(const Fraction&);
    bool operator>=(const Fraction&);
    bool operator==(const Fraction&);
    bool operator!=(const Fraction&);
    friend std::ostream& operator<<(std::ostream&, const Fraction&);
    friend std::istream& operator>>(std::istream&, Fraction&);
    Fraction operator+(Fraction&);
    Fraction operator-(Fraction&);
    Fraction operator*(Fraction&);
    Fraction operator/(Fraction&);
    Fraction& operator=(Fraction&);
    int gcd();
    int lcm();
};

#endif /* fraction_h */
