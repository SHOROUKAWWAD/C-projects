/*
CH08-320143
a6p4.cpp
SHOROUK AWWAD
s.awwad@jacobs-university.de
*/
#include <iostream>
#include "fraction.h"
using namespace std;

int p = 0;
int f = 0;
void test(bool t)
{
    if (t)
        p++;
    else
        f++;
}

int main()
{
    int m=0;
    try {
        Fraction a(2,0);
        p++;
    } catch (string m) {
        cerr << "Caught exception: "<<m << endl;
        f++;
    }

    try {
        Fraction b(1,0);
        p++;
    }catch(string m) {
        cerr << "Caught exception: " <<m << endl;
        f++;
    }


    cout << "Test Operators" << endl;
    cout << "Passed: " << p << " tests" << endl << "Failed: " << f << " tests" << endl;
    return 0;
}
